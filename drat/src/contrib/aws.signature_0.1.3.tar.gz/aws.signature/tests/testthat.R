library("testthat")
library("aws.signature")
#test_check("aws.signature")
