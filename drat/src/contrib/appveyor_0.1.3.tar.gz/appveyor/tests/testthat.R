library("testthat")
library("appveyor")

#test_check("appveyor")
