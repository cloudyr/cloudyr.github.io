context("Accounts")

test_that("check accounts", {
  TRUE
})


context("Users")

test_that("check users", {
  TRUE
})

test_that("add and delete users", {
  TRUE
})


test_that("check roles", {
  TRUE
})

test_that("add and delete roles", {
  TRUE
})

test_that("check collaborators", {
  TRUE
})


context("repo")

test_that("get repo", {
  TRUE
})

test_that("get repo settings", {
  TRUE
})

test_that("environment variables", {
  # get environment variables
  # set environment variables
  TRUE
})

test_that("get build history", {
  TRUE
})

test_that("restart and cancel build", {
  TRUE
})

