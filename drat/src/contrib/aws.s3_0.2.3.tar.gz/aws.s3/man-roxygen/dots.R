#' @param \dots Additional arguments passed to \code{\link{s3HTTP}}.
