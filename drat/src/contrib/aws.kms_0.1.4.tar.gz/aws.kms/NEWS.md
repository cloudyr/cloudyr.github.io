# aws.kms 0.1.4

* Fix invlaid link in the documentation

# aws.kms 0.1.1

* Initial release.
