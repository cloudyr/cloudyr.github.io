# AzureAuth 1.0

* Submitted to CRAN
