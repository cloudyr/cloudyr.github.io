library(testthat)
library(googleCloudStorageR)
library(bigQueryR)


test_check("bigQueryR")
