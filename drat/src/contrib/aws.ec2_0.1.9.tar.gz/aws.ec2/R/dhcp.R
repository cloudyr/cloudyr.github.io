# @references
# \url{http://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_DHCP_Options.html}

# http://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_CreateDhcpOptions.html
create_dhcp_opts <- function() {}

# http://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DeleteDhcpOptions.html
delete_dhcp_opts <- function() {}

# http://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DescribeDhcpOptions.html
describe_dhcp_opts <- function() {}

# http://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_AssociateDhcpOptions.html
associate_dhcp_opts <- function() {}
