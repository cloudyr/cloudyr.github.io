create_association <- function() {} # also batch

delete_association <- function() {}

describe_association <- function() {}

describe_instance_info <- function() {}

list_associations <- function() {}

update_association_status <- function() {}

