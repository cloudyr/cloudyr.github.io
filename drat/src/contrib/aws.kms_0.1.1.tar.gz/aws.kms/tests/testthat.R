library("testthat")
library("aws.kms")

#test_check("aws.kms")
