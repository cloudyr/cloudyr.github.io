# AzureKusto 1.0.2

* Implement `nest` and `unnest` verbs.

# AzureKusto 1.0.1

* Initial CRAN submission.
