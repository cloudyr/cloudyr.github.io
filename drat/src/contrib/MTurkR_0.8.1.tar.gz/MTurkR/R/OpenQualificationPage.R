OpenQualificationPage <- function () {
    browseURL("https://requester.mturk.com/qualification_types")
    invisible(NULL)
}
