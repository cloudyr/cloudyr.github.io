# CHANGES TO aws.sns 0.1.7

* Changed `add_permission()` to `add_topic_permission()` and `remove_permission()` to `remove_topic_permission()` to avoid namespace conflict with **aws.sqs**.

# CHANGES TO aws.sns 0.1.6

* Bump **aws.signature** dependency to 0.3.4.

# CHANGES TO aws.sns 0.1.5

* Add examples and cleanup documentation.

# CHANGES TO aws.sns 0.1.1

* Initial release.
