# aws.translate 0.1.2

* Got client working.

# aws.translate 0.1.1

* Initial release.
