# AzureStor 1.0.0.9000

* Add ADLS upload/download support to `upload_to_url` and `download_from_url`.

# AzureStor 1.0.0

* Submitted to CRAN

# AzureStor 0.9.0

* Moved to cloudyr organisation
