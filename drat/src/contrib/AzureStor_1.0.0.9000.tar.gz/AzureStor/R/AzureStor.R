#' @import AzureRMR
#' @importFrom utils URLencode modifyList packageVersion
NULL

globalVariables("self", "AzureStor")
