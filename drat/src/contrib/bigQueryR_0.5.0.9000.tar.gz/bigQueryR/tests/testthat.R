library(testthat)
library(bigQueryR)


test_check("bigQueryR")
