is_blank <- function(value) {
  return(is.null(value) || value == "")
}