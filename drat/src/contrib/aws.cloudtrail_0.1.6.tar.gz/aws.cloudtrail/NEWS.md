# CHANGES TO aws.cloudtrail 0.1.6

* Update documentation and prepare for CRAN release.

# CHANGES TO aws.cloudtrail 0.1.5

* Update documentation.
* Bump **aws.signature** version to 0.3.4.

# CHANGES TO aws.cloudtrail 0.1.4

* Expand README and examples documentation, using aws.s3 and aws.sns package code.
* Fix various issues and test all package functionality.

# CHANGES TO aws.cloudtrail 0.1.3

* Complete documentation and examples.

# CHANGES TO aws.cloudtrail 0.1.1

* Initial release.
