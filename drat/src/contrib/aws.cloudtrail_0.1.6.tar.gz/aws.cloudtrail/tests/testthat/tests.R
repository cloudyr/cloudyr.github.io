test_that("create_trail", {
    TRUE
})

test_that("update_trail", {
    TRUE
})


test_that("start_logging", {
    TRUE
})

test_that("stop_logging", {
    TRUE
})

test_that("get_trails", {
    TRUE
})

test_that("trail_status", {
    TRUE
})

test_that("delete_trail", {
    TRUE
})
