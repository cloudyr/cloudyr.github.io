create_document <- function() {}

delete_document <- function() {}

describe_document <- function() {}

get_document <- function() {}

list_documents <- function() {}

