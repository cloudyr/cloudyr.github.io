#' @export
AzureAuth::clean_token_directory

#' @export
AzureAuth::delete_azure_token

#' @export
AzureAuth::get_azure_token

#' @export
AzureAuth::is_azure_token

#' @export
AzureAuth::is_azure_v1_token

#' @export
AzureAuth::is_azure_v1_token

#' @export
AzureAuth::is_guid

#' @export
AzureAuth::list_azure_tokens

#' @export
AzureAuth::AzureR_dir
