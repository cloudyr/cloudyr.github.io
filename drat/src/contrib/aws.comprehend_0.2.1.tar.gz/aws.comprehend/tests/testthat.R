library(testthat)
library(aws.comprehend)

test_check("aws.comprehend")
