context("Authenticated object tests")

test_that("basic usage of getobject for signed in user", {
  ex <- get_object(
                  object = 'robots.txt',
                  bucket = 'hpk', 
                  key = Sys.getenv("TRAVIS_AWS_ACCESS_KEY_ID"), 
                  secret = Sys.getenv("TRAVIS_AWS_SECRET_ACCESS_KEY")
  )
  
  expect_is(ex, "response")
  expect_true(
    all(c("url", "status_code", "headers", "all_headers", "cookies", 
      "content", "date", "times", "request") %in% names(ex))
    #  "content", "date", "times", "request", "handle") %in% names(ex))
  )
  expect_equal(ex$status_code, 200)
})

test_that("basic usage of putobject and deleteobject for signed in user", {
  tmp <- tempfile(fileext = ".txt")
  writeLines(c("cloudyr", "test"), tmp)

  p <- put_object(
    file = tmp,
    object = basename(tmp),
    bucket = 'hpk', 
    key = Sys.getenv("TRAVIS_AWS_ACCESS_KEY_ID"), 
    secret = Sys.getenv("TRAVIS_AWS_SECRET_ACCESS_KEY")
  )
  expect_true(p)
  
  d <- delete_object(
    object = basename(tmp),
    bucket = 'hpk',
    key = Sys.getenv("TRAVIS_AWS_ACCESS_KEY_ID"), 
    secret = Sys.getenv("TRAVIS_AWS_SECRET_ACCESS_KEY")
  )
  expect_true(d)
  
  if (file.exists(tmp)) file.remove(tmp)
})
