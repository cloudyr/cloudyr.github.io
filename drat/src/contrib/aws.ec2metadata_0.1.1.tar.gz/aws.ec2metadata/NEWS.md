# CHANGES TO aws.ec2metadata 0.1.1

* Initial release.
