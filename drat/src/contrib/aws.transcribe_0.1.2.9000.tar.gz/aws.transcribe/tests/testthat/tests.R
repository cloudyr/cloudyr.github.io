context("Test aws.transcribe")

test_that("Package works", {
    TRUE # placeholder
})
