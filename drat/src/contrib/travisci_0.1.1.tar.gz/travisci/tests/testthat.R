library("testthat")
library("travisci")

#test_check("travisci")
