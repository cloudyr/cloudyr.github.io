# CHANGES TO aws.ses 0.1.5

* Bump **aws.signature** dependency to 0.3.4.

# CHANGES TO aws.ses 0.1.4

* Fix URL configuration issue.
* Fixed various bugs.
* Expand documentation and examples.

# CHANGES TO aws.ses 0.1.1

* Initial release.
