# AzureCognitive 1.0.0.9000

- Change maintainer email address.

# AzureCognitive 1.0.0

- Initial release to CRAN.
