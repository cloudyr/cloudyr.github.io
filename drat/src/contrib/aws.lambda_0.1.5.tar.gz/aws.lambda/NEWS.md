# CHANGES TO aws.lambda 0.1.4

* Bump **aws.signature** dependency to 0.3.4.

# CHANGES TO aws.lambda 0.1.3

* Rename alias-related functions to avoid namespace clash with aws.iam.

# CHANGES TO aws.lambda 0.1.2

* Update code and documentation.

# CHANGES TO aws.lambda 0.1.1

* Initial release.
