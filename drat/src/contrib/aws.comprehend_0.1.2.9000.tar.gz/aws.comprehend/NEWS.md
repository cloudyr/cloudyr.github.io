# aws.comprehend 0.1.3 (in development)

* **New feature:** `detect_syntax` function to perform syntax analysis (#14)
* Better error message when AWS credentials are not provided (#15)
* Fix missing import of `locate_credential` from `aws.signature` (#5)
* @antoine-sachet taking over as maintainer

# aws.comprehend 0.1.2

* First CRAN release

# aws.comprehend 0.1.1

* Initial release.
