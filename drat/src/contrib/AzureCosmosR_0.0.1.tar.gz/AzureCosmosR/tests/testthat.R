library(testthat)
library(AzureCosmosR)

test_check("AzureCosmosR")
