#' @param qualifier Optionally, either a function version or alias. If omitted, information about the latest version is returned.
