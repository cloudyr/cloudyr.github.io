create_spot_datafeed <- function() {}

delete_spot_datafeed <- function() {}

describe_spot_datafeeds <- function() {}

describe_spot_requests <- function() {}

describe_spot_price <- function() {}

request_spot <- function() {}

