create_reserved_listing <- function() {}

modify_reserved_listing <- function() {}

cancel_reserved_listing <- function() {}

describe_reserved <- function() {}

describe_reserved_listings <- function() {}

describe_reserved_modifications <- function() {}

describe_reserved_offerings <- function() {}

purchase_reserved_listing <- function() {}

