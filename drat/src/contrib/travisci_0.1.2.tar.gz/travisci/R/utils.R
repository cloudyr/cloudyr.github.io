slug_to_id <- function(slug, ...) {
    get_repo(slug, ...)$id
}
