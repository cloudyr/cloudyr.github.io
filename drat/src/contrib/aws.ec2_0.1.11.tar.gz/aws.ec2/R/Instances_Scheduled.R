describe_scheduled_instances <- function() {}

scheduled_availability <- function() {}

buy_scheduled_instances <- function() {}

run_scheduled_instances <- function() {}
