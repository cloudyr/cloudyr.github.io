create_volume <- function() {}

delete_volume <- function() {}

attach_volume <- function() {}

detach_volume <- function() {}

enable_volume_io <- function() {}

get_volume_attr <- function() {}

set_volume_attr <- function() {}

describe_volumes <- function() {}

volume_status <- function() {}




copy_snapshot <- function() {}

create_snapshot <- function() {}

delete_snapshot <- function() {}

get_snapshot_attr <- function() {}

set_snapshot_attr <- function() {}

reset_snapshot_attr <- function() {}

describe_snapshots <- function() {}

