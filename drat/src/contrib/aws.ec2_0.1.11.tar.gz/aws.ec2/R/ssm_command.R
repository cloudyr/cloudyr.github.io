send_command <- function() {}

cancel_command <- function() {}

list_commands <- function() {}

list_command_invocations <- function() {}

