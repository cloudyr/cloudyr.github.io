#' aws.translate 0.1.5 (in development)

#' aws.translate 0.1.4

* Released on CRAN 2020-03-11
* New maintainer @antoine-sachet

# aws.translate 0.1.2

* Got client working.

# aws.translate 0.1.1

* Initial release.
