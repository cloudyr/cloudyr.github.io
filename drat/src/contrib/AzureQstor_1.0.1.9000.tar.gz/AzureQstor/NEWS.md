# AzureQstor 1.0.1

- Change maintainer email address.

# AzureQstor 1.0.0

- Initial CRAN release.
