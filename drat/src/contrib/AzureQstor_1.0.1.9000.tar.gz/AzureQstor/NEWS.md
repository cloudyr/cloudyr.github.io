# AzureQstor 1.0.2

- Transfer to AzureRSDK org on GitHub.

# AzureQstor 1.0.1

- Change maintainer email address.

# AzureQstor 1.0.0

- Initial CRAN release.
