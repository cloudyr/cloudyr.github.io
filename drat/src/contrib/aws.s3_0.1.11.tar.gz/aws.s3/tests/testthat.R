library(testthat)
library(aws.s3)

test_check("aws.s3")
