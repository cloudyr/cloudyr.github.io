context("authentication")

test_that("basic login", {
  auth_travis()
})


context("Accounts")

test_that("check accounts", {
  TRUE
})


context("Users")

test_that("check users", {
  TRUE
})


context("repo")

test_that("get repo", {
  TRUE
})

test_that("get repo settings", {
  TRUE
})

test_that("environment variables", {
  # get environment variables
  # set environment variables
  TRUE
})

test_that("get branch", {
  TRUE
})


test_that("get build", {
  TRUE
})

test_that("restart and cancel build", {
  TRUE
})

test_that("get requests", {
  TRUE
})



context("cache")

test_that("get cache", {
  TRUE
})


context("logs")

test_that("get logs", {
  TRUE
})

context("lint")

test_that("lint", {
  TRUE
})

