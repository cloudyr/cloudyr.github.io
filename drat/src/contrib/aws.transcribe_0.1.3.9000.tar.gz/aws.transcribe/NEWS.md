# aws.transcribe (development version)

# aws.transcribe 0.1.3

* Released on CRAN 2020-03-11
* New maintainer @antoine-sachet

# aws.transcribe 0.1.2

* Finish minimum working example.

# aws.transcribe 0.1.1

* Initial release.
