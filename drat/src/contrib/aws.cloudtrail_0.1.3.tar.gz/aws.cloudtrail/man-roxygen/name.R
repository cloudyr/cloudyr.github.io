#' @param name A character string specifying the name of a Cloudtrail or the ARN for a Cloudtrail.
