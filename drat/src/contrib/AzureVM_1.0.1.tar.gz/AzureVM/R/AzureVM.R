#' @import AzureRMR
NULL

globalVariables("self", "AzureVM")
