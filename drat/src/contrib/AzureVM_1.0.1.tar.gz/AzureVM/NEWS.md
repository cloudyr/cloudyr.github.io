# AzureVM 1.0.1

* Allow resource group and subscription accessor methods to work without AzureVM on the search path.

# AzureVM 1.0.0

* Submitted to CRAN

# AzureVM 0.9.0

* Moved to cloudyr organisation
