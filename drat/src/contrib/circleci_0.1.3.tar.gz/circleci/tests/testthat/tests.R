context("authentication")

test_that("login successful", {
  TRUE
})

context("get projects")

test_that("login successful", {
  TRUE
})


context("builds")

test_that("get builds", {
  TRUE
})

test_that("cancel and retry builds", {
  TRUE
})


context("environment variables")

test_that("add environment variables", {
  TRUE
})

test_that("delete environment variables", {
  TRUE
})
