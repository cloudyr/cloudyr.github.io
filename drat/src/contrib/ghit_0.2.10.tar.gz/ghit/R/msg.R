ghitmsg <- function(verbose, msg) {
    if(verbose) msg
    invisible()
}
