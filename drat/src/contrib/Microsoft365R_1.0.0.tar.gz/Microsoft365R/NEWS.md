# Microsoft365R

- Initial CRAN release
