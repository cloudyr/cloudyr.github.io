# CHANGES TO aws.cloudtrail 0.1.4

* Expand README and examples documentation, using aws.s3 and aws.sns package code.
* Fix various issues and test all package functionality.

# CHANGES TO aws.cloudtrail 0.1.3

* Complete documentation and examples.

# CHANGES TO aws.cloudtrail 0.1.1

* Initial release.
