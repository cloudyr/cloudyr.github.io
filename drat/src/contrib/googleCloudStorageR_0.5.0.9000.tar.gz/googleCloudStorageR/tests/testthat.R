library(testthat)
library(googleCloudStorageR)

test_check("googleCloudStorageR")
