# AzureVision 1.0.2.9000

- Transfer to AzureRSDK org on GitHub.

# AzureVision 1.0.2

- Change maintainer email address.

# AzureVision 1.0.1

- Fix minor error in Custom Vision vignette.

# AzureVision 1.0.0

- Initial CRAN release
