#' @import AzureRMR
NULL

#' @export
AzureRMR::build_template_definition

#' @export
AzureRMR::build_template_parameters

globalVariables("self", "AzureVM")

