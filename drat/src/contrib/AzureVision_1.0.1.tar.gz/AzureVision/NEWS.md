# AzureVision 1.0.1

- Fix minor error in Custom Vision vignette.

# AzureVision 1.0.0

- Initial CRAN release
