library(testthat)
library(aws.lambda)

test_check("aws.lambda")
