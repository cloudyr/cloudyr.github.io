# AzureVM 1.0.0

* Submitted to CRAN

# AzureVM 0.9.0

* Moved to cloudyr organisation
