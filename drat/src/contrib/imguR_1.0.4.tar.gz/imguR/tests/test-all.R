library("testthat")
library("imguR")
test_check("imguR")
