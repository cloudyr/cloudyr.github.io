# imguR 1.0.3

* Added a test suite and travis-CI testing. (#7)
* Migrated imguR to the cloudyr project.

# imguR 1.0.2

* Fixed an error related to passing headers through httr functions. (#6)

# imguR 1.0.1

* Fix R CMD check NAMESPACE notes.

# imguR 1.0.0

* Thomas Leeper takes over as maintainer.
* Package now works with the Imgur v3 API (including OAuth 2.0 support as well as anonymously).
 
# imgur 0.1

* Initial package released by Aaron Statham
