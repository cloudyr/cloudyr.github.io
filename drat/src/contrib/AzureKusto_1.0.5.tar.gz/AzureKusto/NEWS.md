# AzureKusto 1.0.5

* Compatibility update for tidyselect 1.0.0.

# AzureKusto 1.0.4

* Default `queryconsistency` query setting changed to `strongconsistency`, which fixes query errors under certain cluster configurations.
* New maintainer (Alex Kyllo; jekyllo@microsoft.com).

# AzureKusto 1.0.3

* Compatibility update for tidyr 1.0.

# AzureKusto 1.0.2

* Implement `nest` and `unnest` verbs.

# AzureKusto 1.0.1

* Initial CRAN submission.
