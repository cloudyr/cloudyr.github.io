# CHANGES TO aws.polly 0.1.2

* Created separate `synthesize()` and `get_synthesis()` functions. The former as a convenience function wrapping the latter lower-level function.

# CHANGES TO aws.polly 0.1.1

* Initial release.
