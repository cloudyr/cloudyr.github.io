# AzureKeyVault 1.0.1

- Allow tokens to be passed to `key_vault` as character strings, as well as objects of class `AzureToken`.
- Better handling of nulls in API calls.


# AzureKeyVault 1.0.0

- Initial CRAN release
