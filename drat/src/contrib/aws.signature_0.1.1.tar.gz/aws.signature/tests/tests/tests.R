context("AWS Example Test Suite")

test_that("placeholder test",
    expect_true(TRUE)
)
