# CHANGES TO aws.lambda 0.1.2

* Update code and documentation.

# CHANGES TO aws.lambda 0.1.1

* Initial release.
