#' googleCloudStorageR
#'
#' Interact with Google Cloud Storage API in R. Part of the 'cloudyr' project.
#'
#' @docType package
#' @name googleCloudStorageR
NULL
