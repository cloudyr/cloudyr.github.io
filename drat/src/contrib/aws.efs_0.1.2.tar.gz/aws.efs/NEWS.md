# CHANGES TO aws.efs 0.1.2

* Bumped **aws.signature** dependency to 0.3.4

# CHANGES TO aws.efs 0.1.1

* Initial release.
