# AzureVMmetadata 1.0.1.9000

- Transfer to AzureRSDK org on GitHub.

# AzureVMmetadata 1.0.1

- Change maintainer email address.

# AzureVMmetadata 1.0.0

- Initial CRAN release.
