# CHANGES TO awspack 0.1.5

* Export all functions.

# CHANGES TO awspack 0.1.4

* Added **aws.lambda**. (#6)

# CHANGES TO awspack 0.1.3

* Added **aws.iam**. (#2)

# CHANGES TO awspack 0.1.1

* Initial release.
