create_dhcp_opts <- function() {}

delete_dhcp_opts <- function() {}

describe_dhcp_opts <- function() {}

associate_dhcp_opts <- function() {}
