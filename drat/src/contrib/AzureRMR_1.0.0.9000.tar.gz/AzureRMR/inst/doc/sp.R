## ---- eval=FALSE---------------------------------------------------------
#  az <- create_az_login(tenant="tenant", app="app_id", password="password", auth_type="client_credentials")

