# Microsoft365R 1.0.0

- Initial CRAN release.
