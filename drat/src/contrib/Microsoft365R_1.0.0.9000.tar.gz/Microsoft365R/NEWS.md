# Microsoft365R 1.0.0.9000

- Add `bulk_import()` method for lists, for creating multiple items at once. Supply a data frame as the argument.

# Microsoft365R 1.0.0

- Initial CRAN release.
