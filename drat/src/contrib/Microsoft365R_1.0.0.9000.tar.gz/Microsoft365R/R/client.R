#' Login clients for Microsoft 365
#'
#' Microsoft365R provides functions for logging into each Microsoft 365 service.
#'
#' @param tenant For `get_business_onedrive`, `get_sharepoint_site` and `get_team`, the name of your Azure Active Directory (AAD) tenant. If not supplied, use the value of the `CLIMICROSOFT365_TENANT` environment variable, or "common" if that is unset.
#' @param app A custom app registration ID to use for authentication. For `personal_onedrive`, the default is to use Microsoft365R's internal app ID. For `get_business_onedrive` and `get_sharepoint_site`, see below.
#' @param scopes The Microsoft Graph scopes (permissions) to obtain.
#' @param site_name,site_url,site_id For `get_sharepoint_site`, either the name, web URL or ID of the SharePoint site to retrieve. Supply exactly one of these.
#' @param team_name,team_id For `get_team`, either the name or ID of the team to retrieve. Supply exactly one of these.
#' @param ... Optional arguments to be passed to `AzureGraph::create_graph_login`.
#' @details
#' These functions provide easy access to the various collaboration services that are part of Microsoft 365. On first use, they will call your web browser to authenticate with Azure Active Directory, in a similar manner to other web apps. You will get a dialog box asking for permission to access your information. You only have to authenticate once per client; your credentials will be saved and reloaded in subsequent sessions.
#'
#' When authenticating, you can pass optional arguments in `...` which will ultimately be received by `AzureAuth::get_azure_token`. In particular, if your machine doesn't have a web browser available to authenticate with (for example if you are in a remote RStudio Server session), pass `auth_type="device_code"` which is intended for such scenarios.
#'
#' @section Authenticating to Microsoft 365 Business services:
#' Authenticating to Microsoft 365 Business services (Teams, SharePoint and OneDrive for Business) has some specific complexities.
#'
#' The default "common" tenant for `get_team`, `get_business_onedrive` and `get_sharepoint_site` attempts to detect your actual tenant from your saved credentials in your browser. This may not always succeed, for example if you have a personal account that is also a guest account in a tenant. In this case, supply the actual tenant name, either in the `tenant` argument or in the `CLIMICROSOFT365_TENANT` environment variable. The latter allows sharing authentication details with the [CLI for Microsoft 365](https://pnp.github.io/cli-microsoft365/).
#'
#' The default when authenticating to these services is for Microsoft365R to use its own internal app ID. Depending on your organisation's security policy, you may have to get an admin to grant it access to your tenant. As an alternative to the default app ID, you (or your admin) can create your own app registration: it should have a native redirect URI of `http://localhost:1410`, and the "public client" option should be enabled if you want to use the device code authentication flow. You can supply your app ID either via the `app` argument, or in the environment variable `CLIMICROSOFT365_AADAPPID`.
#'
#' If creating your own app registration is impractical, it's possible to work around access issues by piggybacking on the CLI for Microsoft365. By setting the R option `microsoft365r_use_cli_app_id` to a non-NULL value, authentication will be done using the CLI's app ID. Technically this app still requires admin approval, but it is in widespread use and so may already be allowed in your organisation. Be warned that this solution may draw the attention of your admin!
#'
#' @return
#' For `get_personal_onedrive` and `get_business_onedrive`, an object of class `ms_drive`.
#'
#' For `get_sharepoint_site`, an object of class `ms_site`; for `list_sharepoint_sites`, a list of such objects.
#'
#' For `get_team`, an object of class `ms_team`; for `list_teams`, a list of such objects.
#' @seealso
#' [ms_drive], [ms_site], [ms_team], [AzureGraph::create_graph_login], [AzureAuth::get_azure_token]
#'
#' [add_methods] for the associated methods that this package adds to the base AzureGraph classes
#'
#' [CLI for Microsoft 365](https://pnp.github.io/cli-microsoft365/) -- a commandline tool for managing Microsoft 365
#' @examples
#' \dontrun{
#'
#' get_personal_onedrive()
#'
#' # authenticating without a browser
#' get_personal_onedrive(auth_type="device_code")
#'
#' odb <- get_business_onedrive("mycompany")
#' odb$list_items()
#'
#' mysite <- get_sharepoint_site("My site", tenant="mycompany")
#' mysite <- get_sharepoint_site(site_url="https://mycompany.sharepoint.com/sites/my-site-url")
#' mysite$get_drive()$list_items()
#'
#' myteam <- get_team("My team", tenant="mycompany")
#' myteam$list_channels()
#' myteam$get_drive()$list_items()
#'
#' # you can also use your own app registration ID:
#' get_business_onedrive(app="app_id")
#' get_sharepoint_site("My site", app="app_id")
#'
#' # using the app ID for the CLI for Microsoft 365: set a global option
#' options(microsoft365r_use_cli_app_id=TRUE)
#' get_business_onedrive()
#' get_sharepoint_site("My site")
#' get_team("My team")
#'
#' }
#' @rdname client
#' @export
get_personal_onedrive <- function(app=.microsoft365r_app_id,
                                  scopes=c("Files.ReadWrite.All", "User.Read"),
                                  ...)
{
    do_login("consumers", app, scopes, ...)$get_user()$get_drive()
}

#' @rdname client
#' @export
get_business_onedrive <- function(tenant=Sys.getenv("CLIMICROSOFT365_TENANT", "common"),
                                  app=Sys.getenv("CLIMICROSOFT365_AADAPPID"),
                                  scopes=".default",
                                  ...)
{
    app <- choose_app(app)
    do_login(tenant, app, scopes, ...)$get_user()$get_drive()
}

#' @rdname client
#' @export
get_sharepoint_site <- function(site_name=NULL, site_url=NULL, site_id=NULL,
                                tenant=Sys.getenv("CLIMICROSOFT365_TENANT", "common"),
                                app=Sys.getenv("CLIMICROSOFT365_AADAPPID"),
                                scopes=".default",
                                ...)
{
    assert_one_arg(site_name, site_url, site_id, msg="Supply exactly one of site name, URL or ID")
    app <- choose_app(app)
    login <- do_login(tenant, app, scopes, ...)

    if(!is.null(site_name))
    {
        mysites <- login$get_user()$list_sharepoint_sites()
        mysitenames <- sapply(mysites, function(site) site$properties$displayName)
        if(!(site_name %in% mysitenames))
            stop("Site '", site_name, "' not found", call.=FALSE)
        mysites[[which(site_name == mysitenames)]]
    }
    else login$get_sharepoint_site(site_url, site_id)
}

#' @rdname client
#' @export
list_sharepoint_sites <- function(tenant=Sys.getenv("CLIMICROSOFT365_TENANT", "common"),
                                  app=Sys.getenv("CLIMICROSOFT365_AADAPPID"),
                                  scopes=".default",
                                  ...)
{
    app <- choose_app(app)
    login <- do_login(tenant, app, scopes, ...)

    login$get_user$list_sharepoint_sites()
}

#' @rdname client
#' @export
get_team <- function(team_name=NULL, team_id=NULL,
                     tenant=Sys.getenv("CLIMICROSOFT365_TENANT", "common"),
                     app=Sys.getenv("CLIMICROSOFT365_AADAPPID"),
                     scopes=".default",
                     ...)
{
    assert_one_arg(team_name, team_id, msg="Supply exactly one of team name or ID")
    app <- choose_app(app)
    login <- do_login(tenant, app, scopes, ...)

    if(!is.null(team_name))
    {
        myteams <- login$get_user()$list_teams()
        myteamnames <- sapply(myteams, function(team) team$properties$displayName)
        if(!(team_name %in% myteamnames))
            stop("Team '", team_name, "' not found", call.=FALSE)
        myteams[[which(team_name == myteamnames)]]
    }
    else login$get_team(team_id)
}

#' @rdname client
#' @export
list_teams <- function(tenant=Sys.getenv("CLIMICROSOFT365_TENANT", "common"),
                       app=Sys.getenv("CLIMICROSOFT365_AADAPPID"),
                       scopes=".default",
                       ...)
{
    app <- choose_app(app)
    login <- do_login(tenant, app, scopes, ...)

    login$get_user()$list_teams()
}


.ms365_login_env <- new.env()

do_login <- function(tenant, app, scopes, ...)
{
    hash <- function(...)
    {
        as.character(openssl::md5(serialize(list(...), NULL)))
    }

    login_id <- hash(tenant, app, scopes, ...)
    login <- .ms365_login_env[[login_id]]
    if(is.null(login) || !inherits(login, "ms_graph"))
    {
        login <- try(get_graph_login(tenant, app=app, scopes=scopes, refresh=FALSE), silent=TRUE)
        if(inherits(login, "try-error"))
            login <- create_graph_login(tenant, app=app, scopes=scopes, ...)
        .ms365_login_env[[login_id]] <- login
    }
    login
}


choose_app <- function(app)
{
    if(is.null(app) || app == "")
    {
        if(!is.null(getOption("microsoft365r_use_cli_app_id")))
            .cli_microsoft365_app_id
        else .microsoft365r_app_id
    }
    else app
}


assert_one_arg <- function(..., msg=NULL)
{
    arglst <- list(...)
    nulls <- sapply(arglst, is.null)
    if(sum(!nulls) != 1)
        stop(msg, call.=FALSE)
}
