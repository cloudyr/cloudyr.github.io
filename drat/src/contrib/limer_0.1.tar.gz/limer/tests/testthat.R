library(testthat)
library(limer)

# test_check("limer")
