ghitmsg <- function(verbose = FALSE, msg) {
    if(isTRUE(verbose)) {
        msg
    }
    invisible()
}
