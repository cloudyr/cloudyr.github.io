library(testthat)
library(AzureContainers)

test_check("AzureContainers")
