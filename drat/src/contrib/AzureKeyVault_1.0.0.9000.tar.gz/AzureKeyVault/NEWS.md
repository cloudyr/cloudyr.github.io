# AzureKeyVault 1.0.0.9000

- Allow tokens to be passed to `key_vault` as character strings, as well as objects of class `AzureToken`.


# AzureKeyVault 1.0.0

- Initial CRAN release
