#' @param alarm A character vector specifying one or more CloudWatch alarm names.
