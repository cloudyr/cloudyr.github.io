#' @param name A character string specifying a log group name.
