#' @param n The maximum number of records to return.
