#' @param stream A character string specifying a log stream name.
