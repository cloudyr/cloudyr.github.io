# list_metrics <- function(metric, namespace, dimensions, token, ...) {}
# get_metric_stats <- function(metric, namespace, dimensions, period, statistics, unit, start, end, ...) {}
# get_alarms_by_metric <- function(metric, namespace, dimensions, period, statistics, unit, ... ) {}
# put_metric_data <- function() {}
