# CHANGES TO aws.iam 0.1.4

* Documentation fixes. (#5)
* Swapped import of XML to xml2.

# CHANGES TO aws.iam 0.1.3

* Implement the Security Token Service (STS) API. (#4)

# CHANGES TO aws.iam 0.1.3

* All exported functions should be working.
* Add package documentation.

# CHANGES TO aws.iam 0.1.1

* Initial release.
