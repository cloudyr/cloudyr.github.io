context("Authentication")



test_that("Authentication", {
  gcs_auth
})
