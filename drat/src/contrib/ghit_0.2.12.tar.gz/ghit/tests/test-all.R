library("testthat")
library("ghit")
test_check("ghit")
