library(testthat)
library(Microsoft365R)

test_check("Microsoft365R")
