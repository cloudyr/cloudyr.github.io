## Test environments

* local Win 10 install, R 3.5.3
* ubuntu 12.04 (on travis-ci), R 3.6.0
* OSX (on travis-ci), R 3.6.0
* win-builder (release)

## R CMD check results

There were no ERRORs or WARNINGs or NOTEs.

I, Jonathan Stott (jonathan.stott@magairports.com), am the new maintainer.


## Downstream dependencies

I have also run R CMD check on downstream dependencies of aws.signature.
All tests pass